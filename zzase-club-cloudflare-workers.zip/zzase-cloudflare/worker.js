import content from './content.json';
const enc=new TextEncoder();
const json=(obj,status=200,extra={})=>new Response(JSON.stringify(obj),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff',...extra}});
const cookieName='zzase_session';
function bytesToB64(b){let s='';for(const x of b)s+=String.fromCharCode(x);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function b64ToBytes(s){const a=atob(s.replace(/-/g,'+').replace(/_/g,'/'));return Uint8Array.from(a,c=>c.charCodeAt(0))}
async function sign(secret,payload){const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return bytesToB64(new Uint8Array(await crypto.subtle.sign('HMAC',key,enc.encode(payload))))}
function equal(a,b){const x=enc.encode(a),y=enc.encode(b);let diff=x.length^y.length;for(let i=0;i<Math.max(x.length,y.length);i++)diff|=(x[i]||0)^(y[i]||0);return diff===0}
async function authorized(req,env){const cookie=req.headers.get('cookie')||'';const raw=cookie.split(';').map(x=>x.trim()).find(x=>x.startsWith(cookieName+'='))?.slice(cookieName.length+1);if(!raw||!env.SESSION_SECRET)return false;const parts=raw.split('.');if(parts.length!==2)return false;try{const payload=new TextDecoder().decode(b64ToBytes(parts[0]));const data=JSON.parse(payload);if(data.v!==1||!Number.isFinite(data.exp)||Date.now()>data.exp||data.exp>Date.now()+86400000)return false;return equal(await sign(env.SESSION_SECRET,parts[0]),parts[1])}catch{return false}}
const security={'x-content-type-options':'nosniff','referrer-policy':'no-referrer','x-frame-options':'DENY','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"};
export default {async fetch(req,env){const url=new URL(req.url),path=url.pathname;const headers={...security};if(!env.CLUB_PASSWORD||!env.SESSION_SECRET)return json({error:'서버 환경변수가 설정되지 않았습니다.'},503,headers);
if(path==='/api/login'&&req.method==='POST'){
 if(Number(req.headers.get('content-length')||0)>2048)return json({error:'요청이 너무 큽니다.'},413,headers);
 let body;try{body=await req.json()}catch{return json({error:'잘못된 요청입니다.'},400,headers)}
 if(typeof body.password!=='string'||body.password.length>256||!equal(body.password,env.CLUB_PASSWORD))return json({error:'접속 암호가 올바르지 않습니다.'},401,headers);
 const payload=bytesToB64(enc.encode(JSON.stringify({v:1,exp:Date.now()+86400000})));const token=payload+'.'+await sign(env.SESSION_SECRET,payload);
 return json({ok:true},200,{...headers,'set-cookie':`${cookieName}=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=86400`});}
 if(path==='/api/logout'&&req.method==='POST')return json({ok:true},200,{...headers,'set-cookie':`${cookieName}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0`});
 if(path==='/api/session'&&req.method==='GET')return json({authenticated:await authorized(req,env)},200,headers);
 if(path==='/api/content'&&req.method==='GET')return await authorized(req,env)?json(content,200,headers):json({error:'로그인이 필요합니다.'},401,headers);
 if(path.startsWith('/api/'))return json({error:'존재하지 않는 API입니다.'},404,headers);
 if(!['GET','HEAD'].includes(req.method))return new Response('Method Not Allowed',{status:405,headers});
 // Never serve the source content.json directly via public static assets.
 if(path==='/content.json'||path.startsWith('/.')||path==='/worker.js')return new Response('Not Found',{status:404,headers});
 const asset=await env.ASSETS.fetch(req);const h=new Headers(asset.headers);for(const [k,v] of Object.entries(headers))h.set(k,v);if(path==='/'||path==='/index.html')h.set('cache-control','no-store');return new Response(asset.body,{status:asset.status,headers:h});
}};
