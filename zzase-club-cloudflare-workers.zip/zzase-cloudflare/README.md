# 짜세 클럽 가이드 — Cloudflare Workers

## 준비
Node.js 20 이상, Cloudflare 계정 필요. 무료 플랜 사용량과 정책은 Cloudflare 대시보드에서 확인.

## 로컬 실행
1. `npm install`
2. `.dev.vars.example`을 `.dev.vars`로 복사하고 `CLUB_PASSWORD`, `SESSION_SECRET`을 각각 강력한 값으로 변경
3. `npm run dev` 후 터미널에 표시된 localhost 주소 열기

## 배포
1. `npx wrangler login`으로 Cloudflare 로그인
2. `npx wrangler secret put CLUB_PASSWORD` 실행 후 클럽 암호 입력
3. `npx wrangler secret put SESSION_SECRET` 실행 후 임의의 긴 비밀키 입력 (예: PowerShell: `[Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))`)
4. `npm run deploy` 실행
5. 배포 결과에 표시된 `https://zzase-club-guide.<계정>.workers.dev` 주소 접속. 실제 URL은 배포 출력 확인.

**주의:** 비밀키와 암호를 GitHub에 올리지 마세요. `.dev.vars`는 `.gitignore` 처리되어 있습니다. GitHub Actions/Cloudflare 대시보드에서 자동 배포할 때도 secrets를 별도로 설정해야 합니다.

## GitHub 연결 (선택)
GitHub에 새 비공개 저장소 생성 → 프로젝트 파일 업로드(비밀 파일 제외) → Cloudflare Dashboard → Workers & Pages → Create → Import repository에서 저장소 연결. 빌드 설정이 필요한 경우 deploy command는 `npx wrangler deploy`, build command는 `npm install`로 지정. UI 이름은 변경될 수 있습니다. 배포 전 Workers Secrets에 위 두 변수를 설정하세요.

## 기능과 보안
- 클럽 공용 암호 로그인, 서명된 HttpOnly/Secure/SameSite 쿠키 (24시간), 로그아웃
- 가이드/로드맵/공지 검색과 열람. 샘플 내용은 `content.json` 수정 후 재배포
- 콘텐츠는 정적 자산에 포함되지 않고 인증 API에서만 반환
- HTTPS는 workers.dev에서 기본 제공
- 공용 암호 공유 방식이며 회원별 계정/강제 세션 폐기 기능은 없음
- **로그인 시도 제한 기능은 포함되어 있지 않음.** 공개 운영 전 Cloudflare WAF/Rate Limiting 설정 또는 추가 보호 기능을 권장. 무료 제공 범위는 플랜별 확인.
- 비밀번호 변경 시 기존 세션은 만료 전까지 유지될 수 있습니다. 모든 세션을 무효화하려면 SESSION_SECRET도 교체.

## 점검
1. 비로그인 상태에서 `/api/content`는 401
2. `/content.json`은 404
3. 잘못된 암호는 401
4. 올바른 암호 로그인 후 가이드·로드맵·공지 표시
5. 로그아웃 후 `/api/content`는 401
6. 모바일 브라우저와 시크릿 창에서 확인
